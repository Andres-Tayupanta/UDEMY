#include <stdio.h>
#include <stdlib.h>
//Cargar por teclado y almacenar en un vector el peso de 5 personas. Obtener el promedio de los mismos. Contar cu�ntas personas pesan m�s que el promedio y cu�ntas pesan menos.
int main(void) {
  float pesos [5],suma=0, prom;
  int peso_mayor=0,peso_menor=0;
  for(int i=1;i<=5;i++){
   printf("Introduzca el peso del persona %d\n ",i);
   scanf("%f",&pesos[i]);
   suma+=pesos[i];
  }
  prom=suma/5;
  printf("El promedio es %.2f\n",prom);
  for (int i=1;i<=5;i++){
    if(pesos[i]>prom){
      peso_mayor++;
    }else{
      peso_menor++;
    }
  }
  printf("La cantidad de pesos mayores al promedio es %d\n",peso_mayor);
  printf("La cantidad de pesos menores al promedio es %d\n",peso_menor);

  return 0;
}
