#include <stdio.h>
#include <stdlib.h>

//Entrada de un mueso.
int main(void) {
   struct hora_Entrada{
     int hora;
    int minutos;
   };
  struct entrada{
    struct hora_Entrada hora1;
    int asistentes;
    float precio;
  };
  struct entrada e1;

  char continuar ='s';
  float total=0;
  while (continuar=='s'){
    printf("Introduce la hora de entrada\n");
    scanf("%d",&e1.hora1.hora);
    printf("Introduce el minuto de entrada\n");
    scanf("%d",&e1.hora1.minutos);
    printf("Introduce el  numero de asistentes\n");
    scanf("%d",&e1.asistentes);
    for (int i=0;i<e1.asistentes;i++){
      int edad;

      printf("Introduce  la edad del sistetnete %d\n",i+1);
      scanf("%d",&edad);
      if (edad<6){
        total=total+0;
      }else if (edad>=6 && edad <=15){
        total=total+5;
      }else if (edad>=16 && edad<=26 || edad >=65){
        total=total+8;
      }else{
        total=total+10;
      }

    }

    if (e1.asistentes>=5){
      e1.precio=total-(total*0.1);
    }else{
      e1.precio=total;
    }
    printf("Hora del entrada del prupo: %d\n",e1.hora1.hora);
    printf("Minuto de entrada del prupo: %d\n",e1.hora1.minutos);
    printf("El precio total de de las entradas del grupo es: %.2f", e1.precio);
    printf("\n� Quiere continuar  con el otr grupo(s/n)?\n");
    scanf("%s",&continuar);


  }

   printf("\nHasta la proxima....");
  return 0;
}
