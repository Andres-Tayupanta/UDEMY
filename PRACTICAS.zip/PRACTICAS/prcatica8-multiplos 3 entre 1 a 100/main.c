#include <stdio.h>
#include <stdlib.h>
//Escriba un programa que muestre todos los m�ltiplos de 3 entre 1 y 100.
int main(void) {
  int i;
  for (i=1;i<=100;i++){
     if (i%3==0){
       printf("%d\n",i);
     }
  }
  return 0;
}
