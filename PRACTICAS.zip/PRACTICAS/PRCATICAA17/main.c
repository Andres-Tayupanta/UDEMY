#include <stdio.h>
#include <stdlib.h>
/*Crear un vector  de 5 n�meros reales introducidos por teclado. A continuaci�n, declarar un puntero al vector y calcular la media de sus elementos empleando dicho puntero*/
int main(void) {
  float vector[5];
  for (int i=0;i<5;i++){
    printf("Introduce 5 n�meros reales\n");
    scanf("%f",&vector[i]);
  }
  float *puntero=&vector[0];
  float media=0;
  for(int i=0;i<5;i++){
    media=media + *(puntero+i);
  }
  media=media/5;
  printf("La media de los 5 valores es %.2f\n",media);
  return 0;
}
