#include <stdio.h>
#include <stdlib.h>

void menu(){

    printf("BIENVENIDO AL BLACKJACK\n");
    printf("-------------------------\n");
    printf("[1]Juego Nuevo\n");
    printf("[2]Cargar Partidas\n");
    printf("[0]Salir\n");
    printf("=========================\n");
    printf("Ingresa la opcion (digitar el numero correspondiente)\n");

}
