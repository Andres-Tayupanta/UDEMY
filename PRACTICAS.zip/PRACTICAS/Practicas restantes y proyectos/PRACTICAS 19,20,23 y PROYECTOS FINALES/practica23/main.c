#include<stdio.h>
#include<stdlib.h>
/*Declarar un registro llamado con  los campos :
C�digo de tipo entero
Descripci�n de tipo vector caracteres
Precio, de tipo real
definir un puntero de tipo producto y luego reservar un espacio de memoria para alamcenar una variable de tipo producto.
Inicializar los campos del registro creando dinamicamente.
Imprimir campos de registro.
Liberar el espacio din�mico reservado.
*/

struct producto{
  	int codigo;
  	char descripcion[50];
  	float precio;
  };
int main (){

  struct producto *prod;
 prod= malloc(sizeof(struct producto));
 printf("Introduce el codigo:\n");
 scanf("%d",&prod->codigo);
 printf("Introduce la descripcion:\n");
 scanf("%s",prod->descripcion);
 printf("Introduce el precio:\n");
 scanf("%f",&prod->precio);

 printf("\nEl codigo es:%d",prod->codigo);
 printf("\nLa descripcion  es:%s",prod->descripcion);
 printf("\nEl precio es:%.2f",prod->precio);

 free(prod);
 prod=NULL;
  return 0;
}


