#include <stdio.h>
#include <stdlib.h>

int main (){
	int n [3][2]={{0,1},{2,3},{4,5}};
	//printf ("%d",n[1][1]);
	
	for (int i=0;i<3;i++){
		for (int j=0;j<2;j++){
			printf("%d ",n[i][j]);
		}
		printf("\n");
	}
}