#include <stdio.h>
#include <stdlib.h>

int main(){
  //int: 8,-15,19845
  //float: 5.34, 8.97, -100.5
  //double: 1000.653, -200.65
  //char: 't', 'a', '9', '\n'
  int numero_entero= 16;
  float numero_real_simple=5.6;
  double numero_real_doble=1000.44567;
  char caracter='t';
  return  0;
}