#include<stdio.h>
#include<stdlib.h>

int main (){
	char cadena[100]="Esta es una cadena";
	char cadena2 [100]="Esto es una cadena \0";
	char cadena3 [100]={'e','s','t','o','\0'};
	
	for (int i=0;i<=100;i++){
		printf("%c",cadena[i]);
	}
	printf("\n");
	cadena[3]='A';
	printf("%c\n",cadena[3]);
	
	printf("%s\n",cadena3);
	
	printf("INTRDUCE UNA CADENA\n");
    gets(cadena3);
	printf("%s",cadena3);
	
	return 0;
}