#include<stdio.h>
#include<stdlib.h>

int main (){
  int n;
  printf("Introduce el numero de elementos del vector:\n");
  scanf("%d",&n);
 vector[10];
 }