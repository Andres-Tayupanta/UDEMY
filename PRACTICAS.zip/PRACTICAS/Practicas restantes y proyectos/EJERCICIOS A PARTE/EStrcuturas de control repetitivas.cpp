#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int n=0;
  int x=10;
  while(n<10 && x<10){
  	printf("%d\n",n);
  	n++;
  }
  return 0;
}