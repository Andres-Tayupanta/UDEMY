#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int i=2;
  switch(i){
  	case (1):{
  		printf("La variable contiene 1");
		break;
	  }
	  case (2):{
	  	printf("La viariable contiene 2");
		break;
	  }
	  default:{
	  	printf("La variable con contiene los valores 1 ni 2");
		break;
	  }
  }
  return 0;
}