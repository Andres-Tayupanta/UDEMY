#include <stdio.h>
#include<stdlib.h>
 
 int main(){
    int numero=6; 
    int numero2=19;
    float numero3=7.5;
    double numero4=7.5;
    char caracter='t';
    printf("\nEl contenido de la variable numero y numero2 es %d y %d",numero,numero2);
    printf("\nEl contenido de la variable numero3 es %.2f",numero3);
    printf("\nEl contenido de la variable numero4 es %.2lf",numero4);
    printf("\nEl contenido de la variable caracter es %c",caracter);
//Lectura de una variable
int n;
float a;
char b;
printf("\nIntroduce un caracter:\n");
scanf("%c",&b);
printf("El caracter introducido  es %c",b);

printf("\nIntroduce un número:\n");
scanf("%d",&n);
printf("El número entero introducido  es %d\n",n);

printf("\nIntroduce un número float:\n");
scanf("%f",&a);
printf("El número float introducido  es %f\n",a);



 return 0;

 }