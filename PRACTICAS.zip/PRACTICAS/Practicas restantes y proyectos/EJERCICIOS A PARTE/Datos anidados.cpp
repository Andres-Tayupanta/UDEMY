#include <stdio.h>
#include<stdlib.h>
#include <string.h>

int main(void) {
  struct tipo1{
  	int entero1;
  	char carcater1;
  };
   
  struct tipo2{
  	float real1;
  	struct tipo1 variable1;
  };
  
  struct tipo2 variable2={5.5,{7,'c'}};
  printf("%d",variable2.variable1.entero1);
  return 0;
}