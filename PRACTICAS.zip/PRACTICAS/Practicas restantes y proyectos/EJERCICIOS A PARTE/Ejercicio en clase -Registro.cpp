#include <stdio.h>
#include<stdlib.h>
#include <string.h>

int main(void) {
	
  struct miregistro{
  	int dato_Entero;
  	float dato_Float;
  	char dato_Cadena[30];
  	int vector [10];
  };
  struct miregistro  variable;
  variable.dato_Float=5.5;
  variable.dato_Entero=20;
  strcpy (variable.dato_Cadena,"Nueva cadena");
  variable.vector[0]=4;
  
  printf("\nEl dato de registro float es: %.2f",variable.dato_Float);
  struct miregistro vector[10];
  variable.vector[0]=7;
  printf("\nEl dato de tipo entero del primer elemento del vector es: %f",variable.dato_Float);
  return 0;
}