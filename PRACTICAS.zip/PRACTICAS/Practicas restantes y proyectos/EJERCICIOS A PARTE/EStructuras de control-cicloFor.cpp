#include <stdio.h>
#include <stdlib.h>

int main(void) {
  
  for (int x=0;x<=10;x=x+2){
  	printf("%d\n",x);
  }
  
  return 0;
}