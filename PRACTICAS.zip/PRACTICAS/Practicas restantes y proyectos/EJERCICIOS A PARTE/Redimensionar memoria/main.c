#include<stdio.h>
#include<stdlib.h>

int main (){
  //malloc //calloc
  int *vector,n;
  printf("Introduce el numero de elemetos del vector :\n");
  scanf("%d",&n);
  //vector =malloc(n*sizeof(int));
  vector = calloc(n,sizeof (int));
   if(vector==NULL){
   	printf("Error al intentar reservar la memoria\n");
   }else{
   	for(int i=0;i<n;i++){
   		vector[i]=i;

	   }
   }
   int n2=n+3;
   //realloc
   int *vector2=realloc(vector,n2);
 if (vector==NULL){
    printf ("Error al intentar reservar la menoria \n");

 }else{
     vector=vector2;
 }
 for(int i=0;i<n;i++){
    printf ("%d\n",vector[i]);

	   }
}
