#include <stdio.h>
#include <stdlib.h>
//Escribe un programa que realice la conversion euros a pesetas. Para ello, pedirá al usuario que introduzca los euros a convertir y mostrará por consola la equivalencia en pesetas de dicha cantidad.
int main(void) {
  int numero=3;	
  int numero2=7;
  int numero3=1;
  if (numero>0 && numero2>0){
  	if (numero3>0){
  		printf("Los 3 números son ponsitivos\n");
	  }
  }else if (numero>0|| numero2>0){
  	printf("Alguno de los números es positivo\n");
  }else{
  	printf("Ninguno de los dos son positivos\n");
  }
  printf("Fin del programa\n");
  return 0;
}