#include <stdio.h>
#include <stdlib.h>

int main(){
	//Muestra por pantalla el mensaje idicando
	/*Este progrma eemplifica el entorno del desarrollo para escribir porgrmas en lenguae C mediante un instrucci�n que muestra mensae de bienvenida*/
  printf("Hola mundo Lenguaje C\n");
  return  0;
}