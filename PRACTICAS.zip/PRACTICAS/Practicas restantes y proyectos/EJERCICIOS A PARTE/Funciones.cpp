#include <stdio.h>
#include <stdlib.h>
 void suma();
int main(void) {
  suma();
  return 0;
}
void suma(){
	int num1,num2;
	printf("Ingrese el numero1:\n");
	scanf("%d",&num1);
	printf("Ingrese el numero2:\n");
	scanf("%d",&num2);
	int result=num1+num2;
	printf("El resultado de la suma es: %d",result);
}