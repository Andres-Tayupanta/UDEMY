#include <stdio.h>
#include <stdlib.h>

//Entrada de un mueso.
int main(void) {
    int numero=6;
    int *punteroNumero=&numero;
    
    printf("La variable punteroNumero contiene la dirección de memoria %p\n",&punteroNumero);
    
    printf("La el valor de variable punteroNumero es %d\n",*punteroNumero);
    
    char cadena [30]="esta es un acadena prueba";
    char *punteroCadena=&cadena[0];
    
    for (int i=0;i<30;i++){
    	printf("%c ",*(punteroCadena+i));
	}
   printf("\n");
    int vector [5] ={1,2,3,4,5};
    int  *punteroVector=&vector[0];
    for (int i=0;i<=5;i++){
    	printf("%d",*(punteroVector +i ));
	}
	printf ("\n");
	struct registro {
	int num;
	char car;	
	};
    struct registro r1;
    struct registro *r2=&r1;
    (*r2).num=5;
    (*r2).car='a';
    printf("El campo num de la estructura a que punta r2 es: %d\n ",(*r2).num);
    printf("El campo de la r1 es: %c\n ",(*r2).car);
  return 0;
}