#include <stdio.h>
#include <stdlib.h>
//Escribe un programa que realice la conversion euros a pesetas. Para ello, pedirá al usuario que introduzca los euros a convertir y mostrará por consola la equivalencia en pesetas de dicha cantidad.
int main(void) {
  /*int valor;
  typedef int entero;
  entero valor1;
  entero valor2;
  typedef long entero_largo;
  entero_largo valor ;*/
  
  typedef enum {lunes,martes,miercoles,jueves,viernes,sabado,domingo} semana;
  semana dia_semana1=lunes;
  if (dia_semana1==lunes){
  	printf("Estamos en lunes\n");
  }else{
  	printf("No Estamos en lunes\n");
  }
  
  
  return 0;
}