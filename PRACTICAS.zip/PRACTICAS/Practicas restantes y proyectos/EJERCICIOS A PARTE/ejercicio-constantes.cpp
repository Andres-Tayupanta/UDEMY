#include <stdio.h>
#include <stdlib.h>
#define PI 3.14

int main(void) {
  float resultado;
  int radio;
  printf("Introduzca el radio del círculo:\n");
  scanf("%d",&radio);
  resultado=radio*PI;
  printf("El área del círculo es: %.2f",resultado);
  return 0;
}