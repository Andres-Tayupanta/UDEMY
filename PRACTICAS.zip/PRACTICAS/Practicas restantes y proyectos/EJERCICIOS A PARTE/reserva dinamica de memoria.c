#include<stdio.h>
#include<stdlib.h>

int main (){
  //malloc //calloc
  int *vector,n;
  printf("Introduce el numero de elemetos del vector :\n");
  scanf("%d",&n);
  //vector =malloc(n*sizeof(int));
  vector = calloc(n,sizeof (int));
   if(vector==NULL){
   	printf("Error al intentar reservar la memoria\n");
   }else{
   	for(int i=0;i<n;i++){
   		printf("Elemento en la posici�n %d es %d\n",i,vector[i]);
	   }
   }

return 0;
}
