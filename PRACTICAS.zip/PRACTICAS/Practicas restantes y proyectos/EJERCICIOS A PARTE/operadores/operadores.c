#ifndef OPERADORES_C_INCLUDED
#define OPERADORES_C_INCLUDED

int sumar(int op1,int op2){
   return op1+op2;
 }
int restar(int op1,int op2){
  return op1-op2;
}
int mutiplicar(int op1,int op2){
  return op1*op2;
}
float dividir(int op1,int op2){
  if(op2==0){
    return 0;
  }else{
    return (float)op1/op2;
  }

}

#endif // OPERADORES_C_INCLUDED
