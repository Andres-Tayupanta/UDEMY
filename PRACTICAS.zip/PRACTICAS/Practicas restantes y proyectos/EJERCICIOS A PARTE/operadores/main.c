#include <stdio.h>
#include <stdlib.h>
#include "operadores.h"
int main()
{
int o1,o2;
int rssuma,rsresta,rsmult;
float rsdivi;
printf("Ingrese el operando 1\n");
scanf("%d",&o1);
printf("Ingrese el operando 2\n");
scanf("%d",&o2);
rssuma=sumar(o1, o2);
rsresta=restar(o1, o2);
rsmult=mutiplicar(o1, o2);
rsdivi=dividir(o1, o2);
printf("Suma: %d\n",rssuma);
printf("Resta: %d\n",rsresta);
printf("Multiplicacion: %d\n",rsmult);
printf("Division: %f\n",rsdivi);

}
