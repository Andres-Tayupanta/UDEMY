#ifndef OPERADORES_H_INCLUDED
#define OPERADORES_H_INCLUDED
int sumar(int op1,int op2);
int restar(int op1,int op2);
int mutiplicar(int op1,int op2);
float dividir(int op1,int op2);



#endif // OPERADORES_H_INCLUDED
