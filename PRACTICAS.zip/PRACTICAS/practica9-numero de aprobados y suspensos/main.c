#include <stdio.h>
#include <stdlib.h>
//Desarrolla un programa que solicite la carga de un n�mero de al usuario. A continuaci�n, deber� pedir las notas de ese n�mero de alumnos y mostrar por pantlla el n�mero de alumnos aprobados y suspensos.
int main(void) {
  int i,n, aprobados=0,suspensos=0;
  float nota;
  printf("Introduzca el n�mero de alumnos:\n");
  scanf("%d",&n);
  for (i=1;i<=n;i++){
    printf("Introduzca las notas del alumno %d:\n",i);
    scanf("%f",&nota);
     if (nota>=5){
       aprobados++;


     }else{
       suspensos++;
     }
  }
  printf("El n�mero de aprobados es %i y el alumnos suspensos es %i",aprobados,suspensos);
  return 0;
}
