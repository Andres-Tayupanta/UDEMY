#include <stdio.h>
#include <stdlib.h>
//Escriba un progrma que pia ala usuario su nota y conpruebe si ha suspenso (<5),si ha sacado un suficiente (5), un bien(6), un notable (7-8) o un sobresaliente (9-10)
int main(void) {
  float nota;
  printf("introduzca la nota del alumno: \n");
  scanf("%f",&nota);
  if (nota<5){
    printf("Suspenso\n");
  }else if (nota==5){
    printf("Suficiente\n");
  } else if (nota==6){
    printf("Bien\n");
  }else if(nota==7||nota==8){
    printf("Notable\n");
  }else if (nota==9||nota==10){
    printf("Sobresaliente\n");
  }else{
    printf("Nota introducida no v�lida\n");
  }

  return 0;
}
