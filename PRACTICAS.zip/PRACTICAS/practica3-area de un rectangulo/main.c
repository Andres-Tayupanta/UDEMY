#include <stdio.h>
#include <stdlib.h>

/*Escribe un progrma que pida al usuario al valor de la base y la altura de un rectangulo y con ellos calcule se �rea. A=bxh*/

int main(void) {
  float altura,base;
  printf("Introduzca la base del rectangulo: \n");
  scanf("%f",&base);
  printf("Introduzca la altura del rectangulo: \n");
  scanf("%f",&altura);
  float result=base*altura;
  printf("El area del rectagulo de base %.2f y altura %.2f es: %.2f",base,altura,result);
  return 0;
}
