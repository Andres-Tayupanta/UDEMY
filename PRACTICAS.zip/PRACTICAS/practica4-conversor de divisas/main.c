#include <stdio.h>
#include <stdlib.h>
//Escribe un programa que realice la conversion euros a pesetas. Para ello, pedir� al usuario que introduzca los euros a convertir y mostrar� por consola la equivalencia en pesetas de dicha cantidad.
int main(void) {
  float euros;
  printf("Introduzca los euros que quiere convertir\n");
  scanf("%f",&euros);
  //pesetas=euros*166.386
  printf("%.2f euros equivalen a %.2f pesetas", euros,euros*166.386);
  return 0;
}
