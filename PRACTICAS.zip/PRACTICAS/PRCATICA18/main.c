#include <stdio.h>
#include <stdlib.h>
/*Escribir una funci�n qu reciba como par�metros un vector entero (por referencia) y la longitud del vector y un n�mero(por valor). La funcion debe multiplicar el vector por el n�mero*/
void multiplicacon_vector(int *vector,int numElementos,int num);
int main(void) {
int vector[10]={1,2,3,4,5,6,7,8,9,10};
 multiplicacon_vector(&vector[0],10,3);
  for(int i=0;i<10;i++){
    printf("%d ",vector[i]);
  }
  return 0;
}
void multiplicacon_vector(int *vector,int numElementos,int num){

  for (int i=0;i<numElementos;i++){
    *(vector+i)=*(vector+i)*num;
  }
}
