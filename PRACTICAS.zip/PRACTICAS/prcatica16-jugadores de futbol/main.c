#include <stdio.h>
#include<stdlib.h>
#include <string.h>
/*Crear un programa que pida al usuario los nombre,edades,y alturas de los jugadores de un equipo de baloncesto (5jugadores). Posteriormente le presentar�n un men� que le permita:
1.Listar los nombres y alturas de los jugadores.
2.Buscar un jugador por su nombre y presentar su altura y su edad.
3.Indicar el nombre y la edad del jugador m�s alto del equipo.*/
int main(void) {
  struct jugador{
   char nombre [50];
   int edad;
  float altura;
  };
  struct jugador jugadores[5];
  for (int i=0;i<5;i++){
    printf("Ingrese el nommbre del jugador %d\n",i+1);
    gets(jugadores[i].nombre);
    printf("Ingrese la edad del jugador %d\n",i+1);
    scanf("%d",&jugadores[i].edad);
    printf("Ingrese la altura del jugador %d\n",i+1);
    scanf("%f",&jugadores[i].altura);

    fflush(stdin);
  }
  int opcion=-1;
  while(opcion!=0){
    printf("\nEscoga una opci�n que desea realizar:\n 1.-Listar los nombres y alturas de los jugadores\n 2.-Buscar un jugador por su nombre y presentar su altura y su edad.\n 3.- Indicar el nombre y la edad del jugador m�s alto del equipo.\n 0.-Salir\n");
    scanf("%d",&opcion);
    fflush(stdin);
    if (opcion==1){
      for(int i=0;i<5;i++){
        printf("\nJugador de nombre %s y de altura %.2f ",jugadores[i].nombre,jugadores[i].altura);
      }
    }
    if (opcion==2){
      char nombreJugador[50];
      int encontrado=0;
      printf("\nIngrse el nombre del jugador a buscar:\n");
      gets(nombreJugador);

      for (int i=0;i<5;i++){
       if ( strcmp(jugadores[i].nombre,nombreJugador)==0){
         encontrado=1;
         printf("\nLa altura del jugador es %.2f y su edad es %d",jugadores[i].altura,jugadores[i].edad);
       }
        if (encontrado==0){
          printf("\nJugador no encontrado\n");
        }
      }
    }
    if(opcion==3){
      float mayor=jugadores[0].altura;
      int mayor_edad=jugadores[0].edad;
      char nombre_mayor[50];
      strcpy(nombre_mayor,jugadores[0].nombre);
      for (int i=0;i<5;i++){
        if(jugadores[i].altura>mayor){
          strcpy(nombre_mayor,jugadores[i].nombre);
          mayor_edad=jugadores[i].edad;
          mayor=jugadores[i].altura;
        }
      }
      printf("\nEl nombre del jugador con mayor altura es %s y su edad es %d\n",nombre_mayor,mayor_edad);
    }
  }

  return 0;
}
