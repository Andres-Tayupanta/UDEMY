#include <stdio.h>
#include <stdlib.h>

//En un hotel la informaci�n de las habitaciones se guarda en un vector bidimensional. Cada posisci�n del vector es a su vez otro vector en el que la primera posici�n indica el n�mero de habitaci�n y las tres siguientes posiciones el precio de la habitaci�n en temporada baja, media y alta.
//Escribe un programa en el que se define una matriz como la anterior y muestre el promedio de cada una de la temporadas.
int main (){
  int informacion [3][4]={{1,120,150,220},{2,130,160,230},{3, 100,120,200}};
  int i,j,temporadaBaja=0,temporadaMedia=0,temporadaAlta=0;
  float promedio_temporadaBaja,promedio_temporadaMedio,promedio_temporadaAlta;
  for (i=0;i<3;i++){
    for(j=1;j<=4;j++){
      if(j==1){
        temporadaBaja=temporadaBaja+informacion[i][j];
      }
      if(j==2){
        temporadaMedia=temporadaMedia+informacion[i][j];
      }
      if(j==3){
        temporadaAlta=temporadaAlta+informacion[i][j];
      }
    }
  }
  promedio_temporadaBaja=temporadaBaja/3;
  promedio_temporadaMedio=temporadaMedia/3;
  promedio_temporadaAlta=temporadaAlta/3;
  printf("El promedio de en la temporada baja es: %.2f\n",promedio_temporadaBaja);
  printf("El promedio de en la temporada media es: %.2f\n",promedio_temporadaMedio);
  printf("El promedio de en la temporada alta es: %.2f",promedio_temporadaAlta);
  return 0;
}
