#include <stdio.h>
#include <stdlib.h>

int main(){
  printf("Hola mundo Lenguaje C\n");
  return  0;
}
