#include <stdio.h>
#include <stdlib.h>
//Desarrolla un programa que solicite constantemente la carga de un n�mero al usuario. El programa finalizar� cuando el usuario introduzca un 0, momento en el que se debe visualizar la suma y el promedio de todos los n�meros.
int main(void) {
  int i,cont=0;
  float numero,prom,suma=0;

  while (numero!=0){
    printf("Introduce un n�mero:\n");
    scanf("%f",&numero);
    cont++;
    suma+=numero;
  }
  prom=suma/cont;
  printf("La suma de los numeros es %.2f y el promedio es %.2f ",suma,prom);
  return 0;
}
