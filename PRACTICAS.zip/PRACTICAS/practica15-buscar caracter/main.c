#include <stdio.h>
#include<stdlib.h>
#include <string.h>
//Deasarrolle un programa que pida por teclado una cadena y un caracter y de vuelva si dicho caracter se encuentra en la cadena y si es asi, la posici�n de la primera aparici�n del mismo.
int main(void) {
  int i=0;
  int poss=-1;
  char cadena1[50],caracter;
  printf("Indroduce una cadena:\n");
  gets(cadena1);
  printf("Indroduce un caracter:\n");
  caracter=getchar();
  while(cadena1[i]!='\0'&&poss==-1){
    if (cadena1[i]==caracter){
      poss=i;
    }
    i=i+1;
  }
 if (poss!=-1){
   printf("El caracter %c se encuentra en la cadena %s en la posici�n %i",caracter,cadena1,poss);
 }else{
   printf ("El caracter %c no se encuentra en la cadena %s",caracter,cadena1);
 }
  return 0;
}
