#include <stdio.h>
#include <stdlib.h>
//Escriba un progrma que se utilice para cualcular el precio final de vente de coches de segunda mano de un concesionario. Para ello, el programa debe pedir al usuario que introduzca el precio base del veh�culo, el n�mero de kil�metros y su consumo.
//Si los kil�metros son inferiores a 20000 y su consumo igual o inferior a 5, incrementar el precio base un 20%.
//Si los kil�metros son superiores a 20000 y su consumo igual o inferior a 5 incrementar el precio base un 10%.
//Si el consumo es superior a 5, incrementsr el precio base un 5%.
int main(void) {
  int precio_base,kilometros;
  float consumo;
  float precioFinal;
  printf("Introduzca el precio base del veh�culo: \n");
  scanf("%d",&precio_base);
  printf("Introduzca los kil�metros: \n");
  scanf("%d",&kilometros);
  printf("Introduzaca el cosumo:\n");
  scanf("%f",&consumo);

  if (kilometros<20000 && consumo<=5){
    precioFinal=precio_base*1.2;
  }else if (kilometros>20000 && consumo<=5){
    precioFinal=precio_base*1.1;
  } else if (consumo>5){
    precioFinal=precio_base*1.05;
  }
  printf("El precio final es de: %.2f",precioFinal);
  return 0;
}
