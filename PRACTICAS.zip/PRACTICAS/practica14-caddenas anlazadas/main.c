#include <stdio.h>
#include<stdlib.h>
#include <string.h>
//Escribir un programa que �da 4 cadenas por teclado y las muestre por la salida separas por un "-"
int main(void) {
  char cadena1[50],cadena2[50],cadena3[50],cadena4[50];
  printf("Indroduce la primera cadena:\n");
  gets(cadena1);
  printf("Indroduce la segunda cadena:\n");
  gets(cadena2);
  printf("Indroduce la tercera cadena:\n");
  gets(cadena3);
  printf("Indroduce la cuarta cadena:\n");
  gets(cadena4);

  printf("%s-%s-%s-%s",cadena1,cadena2,cadena3,cadena4);
  return 0;
}
